-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Sep 03, 2021 at 09:15 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `organizer`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Id` int(11) NOT NULL,
  `Full_Name` varchar(100) NOT NULL,
  `User_Name` varchar(100) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Image_Name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`Id`, `Full_Name`, `User_Name`, `Email`, `Password`, `Image_Name`) VALUES
(1, 'Mosarrat Shazia Kabir', 'MSK', 'msk@gmail.com', '1234', 'Service_Category_930.jpeg'),
(2, 'Sayeda Karishma Naaz', 'SKN', 'skn@gmail.com', '4321', 'Events_Image_791.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) UNSIGNED NOT NULL,
  `event` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(255) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_contact` int(20) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_address` varchar(255) NOT NULL,
  `preference` varchar(255) NOT NULL,
  `appointment_made` datetime NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `event`, `price`, `date`, `time`, `customer_name`, `customer_contact`, `customer_email`, `customer_address`, `preference`, `appointment_made`, `status`) VALUES
(2, 'Office Orientation', '25500.00', '2021-09-10', 'Afternoon', 'Shazia Kabir', 1987654323, 'shazia@gmail.com', 'Gulshan-02, Dhaka-1200', 'Black and Whit theme', '2021-08-30 09:08:14', 'Appoint'),
(3, 'Home party', '8000.00', '2021-08-31', 'Afternoon', 'Mahadia Mahi', 1987019876, 'mahi@gmail.com', 'Banani-11, Dhaka', 'None', '2021-08-30 01:48:23', ' Cancelled'),
(4, 'Engagement', '35500.00', '2021-09-03', 'Afternoon', 'Karishma', 2147483647, 'skn@gmail.com', 'Puran Dhaka', 'I want a Instagram photo wall. ', '2021-08-31 07:07:53', 'Completed'),
(5, 'Graduation Party', '13500.00', '2021-09-03', 'Afternoon', 'Tahmid Kabir', 1987654322, 'tahmid@gmail.com', 'DIC, Aftabnagar.', 'I want a crackers spot', '2021-08-31 07:53:19', 'Appoint'),
(6, 'Mehendi Ceremony', '35500.00', '2021-09-25', 'Afternoon', ' Sayeda Naaz', 1298367541, 'skn@gmail.com', 'Basundhara.', 'Red-yellow theme....', '2021-09-01 10:04:47', 'Appoint');

-- --------------------------------------------------------

--
-- Table structure for table `cancel`
--

CREATE TABLE `cancel` (
  `id` int(11) UNSIGNED NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_contact` int(20) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `customer_address` varchar(255) NOT NULL,
  `event` varchar(255) NOT NULL,
  `price` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `preference` varchar(255) NOT NULL,
  `appointment_made` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cancel`
--

INSERT INTO `cancel` (`id`, `customer_name`, `customer_contact`, `customer_email`, `customer_address`, `event`, `price`, `date`, `time`, `preference`, `appointment_made`) VALUES
(1, 'Mahadia Mahi', 1987019876, 'mahi@gmail.com', 'Banani-11, Dhaka', 'Home party', '8,500', '2021-08-31', 'Afternoon', 'None', '2021-08-30 01:48:23');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Id` int(11) UNSIGNED NOT NULL,
  `Title` varchar(100) NOT NULL,
  `Image_Name` varchar(100) NOT NULL,
  `Active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Id`, `Title`, `Image_Name`, `Active`) VALUES
(1, 'Casual Event', 'Service_Category_412.jpg', 'Yes'),
(2, 'Formal Events', 'Service_Category_972.jpg', 'Yes'),
(3, 'Wedding Events', 'Service_Category_299.jpg', 'Yes'),
(4, 'Catering Service', 'Service_Category_880.jpg', 'Yes'),
(5, 'Photographer', 'Service_Category_700.jpg', 'Yes'),
(6, 'Convention Halls', 'Service_Category_621.jpg', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `Id` int(11) UNSIGNED NOT NULL,
  `Title` varchar(100) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Price` varchar(150) NOT NULL,
  `Image_Name` varchar(255) NOT NULL,
  `Category_Title` varchar(255) NOT NULL,
  `Active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`Id`, `Title`, `Description`, `Price`, `Image_Name`, `Category_Title`, `Active`) VALUES
(1, 'Birthday', 'Decoration, One photo wall decoration, cake & 3-cusine of choice', '6000', 'Service_Category_129.jpg', 'Casual Event', 'Yes'),
(2, 'Home party', ' Decoration, 4 cuisine of choice with welcome drink', '8500', 'Service_Category_524.jpg', 'Casual Event', 'Yes'),
(4, 'Baby Shower', 'Decoration, Cake, 5 cuisine with Return Gift', '12500', 'Service_Category_812.jpg', 'Casual Event', 'Yes'),
(5, 'Bridal Shower', 'Decoration, Cake, 5 cuisine with Return Gift', '12500', 'Service_Category_758.png', 'Casual Event', 'Yes'),
(6, 'Graduation Party', ' Decoration, 6 cuisine of choice with welcome drink', '13500', 'Service_Category_233.jpg', 'Formal Events', 'No'),
(9, 'Office Orientation', 'Decoration, Own choice of  Food menu  ', '25500', 'Service_Category_33.jpg', 'Formal Events', 'Yes'),
(10, 'Engagement', 'Decoration, Cake, Own choice of  Food menu ', '35000', 'Service_Category_715.jpg', 'Casual Event', 'Yes'),
(11, 'Mehendi Ceremony', 'Decoration, Own choice of  Food menu ,Photographer', '35500', 'Service_Category_288.jpg', 'Casual Event', 'No'),
(12, 'Holud ', 'Decoration, Own choice of  Food menu  , Photographer', '40500', 'Service_Category_360.jpg', 'Casual Event', 'No'),
(13, 'Akht ', 'Decoration, Cake, Own choice of  Food menu  , Photographer', '38500', 'Service_Category_853.jpg', 'Casual Event', 'No'),
(14, 'Sangeet Ceremony', 'Decoration, Cake, Food menu with photographer & Music System', '39800', 'Service_Category_670.jpg', 'Casual Event', 'No'),
(16, 'Anniversary Party', 'Decoration, Cake, Food menu with photographer & Return Gift', '48600', 'Service_Category_351.jpg', 'Casual Event', 'No'),
(17, 'Wedding ', 'Decoration, Cake, Food menu, photographer ', '50000', 'Service_Category_227.jpg', 'Casual Event', 'No'),
(18, 'Reception', 'Decoration, Cake, Own choice of  Food menu  , Photographer', '55000', 'Service_Category_586.jpg', 'Casual Event', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `Id` int(11) UNSIGNED NOT NULL,
  `Full_Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `review` varchar(255) NOT NULL,
  `Active` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`Id`, `Full_Name`, `Email`, `review`, `Active`) VALUES
(1, 'Shazia Kabir', 'shazia@gmail.com', 'I Love Their Services.', 'Yes'),
(2, 'Mahadia Mahi', 'mahi@gmail.com', 'Just so so....', 'Yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cancel`
--
ALTER TABLE `cancel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cancel`
--
ALTER TABLE `cancel`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `Id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `Id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `Id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
